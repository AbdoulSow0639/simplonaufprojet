part of 'values.dart';

class MesDimensions {

  // static const double largeurConteneurMobile = 450;
  static const double hauteurConteneurMobile = 917;

  static const double largeurConteneurImage = 155;
  static const double hauteurConteneurImage = 155;

  static const double paddingHorizontalConteneurMobile = 22;
  static const double paddingVerticalConteneurMobile = 60;

  static const double hauteurAppBar = 72;

  static const double hauteurSideBox = 45;

  static const double tailleEcriture =12;
  static const double tailleTitreEcriture = 18;

  static const double tailleDix =  10;
  static const double tailleCinq = 5;
  static const double taille130 = 130;
  static const double taille150 = 150;
  static const double taille39 = 39;
  static const double taille300 = 300;
  static const double taille200 = 200;
  static const double taille100 = 100;
  static const double taille20 = 20;
  static const double taille30 = 30;
  static const double taille14 = 14;

  static const double espacementHauteurContainer = 50;

  static const double taille1 = 1;

}