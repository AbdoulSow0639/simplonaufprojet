part of 'values.dart';


class MesCouleurs {

  static const Color maCouleurRouge = Color.fromRGBO(161, 22, 22, 1);
  static const Color maCouleurBlanche = Colors.white;
  static const Color maCouleurBleue = Color.fromARGB(255, 109, 149, 201);
  static const Color maCouleurNoir = Color.fromARGB(255, 0, 0, 0);
}