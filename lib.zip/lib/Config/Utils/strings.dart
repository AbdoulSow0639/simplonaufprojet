part of 'values.dart';

class MesTextes {

  static const String logoName = "devAUF";

  static const String monNom = "SACKO Sekou Oumar";
  static const String monEmail = "sekououmar978@gmail.com";
  static const String monNumero = "+224 626 37 89 71";

  static const String competence1 = "Flutter";
  static const String competence2 = "Html";
  static const String competence3 = "PHP";

  static const String voirPlus = "Voir plus";

  static const String bienvenue = "Bienvenue";

  static const monNom2 = "Grafikart";
  static const monProfil = "Developpeur FullStack";
  static const monAdresse = "Coyah - GUINEE";

  static const emissionTexte = "Emission Streaming";

  static const editTexte = "Edit";
  static const detailTexte = "Detail";

  static const coursJsTexte = "Cours JavaScript";

  static const description1 = "Comprendre les bases du langage";
  static const description2 = "Comprendre les bases du langage";
  static const description3 = "Comprendre les bases du langage";

  static const detailEmissionTexte = "Detail Emission";
  static const editProfilTexte = "Edition Profil";
  

  static const modificationTexte ="Modification";

  static const champ1Formulaire = "Entrer votre nom";
  static const champ2Formulaire = "Entrer votre profil";
  static const champ3Formulaire = "Entrer votre adresse";

  static const libelle1Formulaire = "Nom";
  static const libelle2Formulaire = "Profil";
  static const libelle3Formulaire = "Adresse";

  static const bouttonModifierTexte = "Modifier";

}